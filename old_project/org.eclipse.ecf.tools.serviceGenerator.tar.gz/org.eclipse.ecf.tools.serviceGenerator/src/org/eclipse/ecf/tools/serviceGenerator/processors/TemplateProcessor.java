package org.eclipse.ecf.tools.serviceGenerator.processors;

import java.util.List;

import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.ecf.tools.servicegenerator.templates.ImpleTemplate;
import org.eclipse.ecf.tools.servicegenerator.templates.InterfaceTemplate;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.JavaModelException;

public class TemplateProcessor {
	private IPackageFragmentRoot root;
	private IJavaProject javaProject;
	
	public TemplateProcessor(IJavaProject javaProject){
		
		 this.javaProject = javaProject;
		 IFolder srcFolder = javaProject.getProject().getFolder("src");
		 root = javaProject.getPackageFragmentRoot(srcFolder);
	}
	
	public void generateTemplate(String newClazz, List<String> importsList,
			String pacKname, List<String[]> strMethod)
			throws JavaModelException, CoreException {
		
		 IPackageFragment sourcePackage = root.createPackageFragment(pacKname, false, null);
		 String template = InterfaceTemplate.getClassTemplete(pacKname,importsList,newClazz,strMethod);
		 sourcePackage.createCompilationUnit(newClazz+".java", template, false, null);
		 javaProject.getProject().refreshLocal(IResource.DEPTH_INFINITE,new NullProgressMonitor());
	}
 

	public void generateImpleTemplate(String newClazz,String packgeName,
			List<String> importsList, String interfaceName,
			List<String[]> methods) throws CoreException {
		IPackageFragment sourcePackage = root.createPackageFragment(packgeName, false, null);
		String impleTemplete = ImpleTemplate.getImpleTemplete(packgeName, importsList, newClazz,
				interfaceName, methods);
		
		sourcePackage.createCompilationUnit(newClazz+".java", impleTemplete, false, null);
		javaProject.getProject().refreshLocal(IResource.DEPTH_INFINITE,new NullProgressMonitor());
	}
	

}
