package org.eclipse.ecf.tools.servicegenerator.handler;

import java.io.File;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IncrementalProjectBuilder;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.ecf.tools.serviceGenerator.annotaions.Async;
import org.eclipse.ecf.tools.serviceGenerator.processors.AnnotaionProcessor;
import org.eclipse.ecf.tools.serviceGenerator.processors.IResourcesProcessor;
import org.eclipse.ecf.tools.serviceGenerator.processors.TemplateProcessor;
import org.eclipse.jdt.core.IAnnotation;
import org.eclipse.jdt.core.IClasspathEntry;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IImportContainer;
import org.eclipse.jdt.core.IImportDeclaration;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IMethod;
import org.eclipse.jdt.core.IPackageDeclaration;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IActionDelegate;
import org.eclipse.jst.ws.annotations.core.utils.*;

import com.sun.xml.internal.txw2.Document;
import com.sun.mirror.declaration.AnnotationMirror;

public class ServiceGenHandler  implements IActionDelegate{

	private URLClassLoader jdbcJarLoader;
	private List<URL> urls;
	private IStructuredSelection selection;
	private String clazzFQ; 
	private String generatedInterfaceName;
	private List<String> importsList;
	private String pacKagename;
	private List<String[]> methodSignatures;


	@Override
	public void run(IAction arg0) {
		if (selection != null) {
			 try {
				 clazzGen(selection);
			} catch (Exception e) {
			 
			}
		}
		
	}
		  
	@Override
	public void selectionChanged(IAction arg0, ISelection selection) {
		
		if (selection instanceof IStructuredSelection) {
			this.selection = (IStructuredSelection) selection;
		}	
	}

	private void clazzGen(ISelection selection) {
		try { 

		 IStructuredSelection StructuredSelection = (IStructuredSelection) selection;
		 ICompilationUnit compilationUnit =(ICompilationUnit) StructuredSelection.getFirstElement();
		 
		 IJavaProject javaProject = IResourcesProcessor.getJavaProject(compilationUnit);
		 IPath outputLocation = javaProject.getOutputLocation();
		 String	projectClasspath = ResourcesPlugin.getWorkspace().getRoot().getFolder(outputLocation).getLocation().toFile()
					.toString();
		 
		 addClasspaths(javaProject.getRawClasspath(),projectClasspath);
		 clazzFQ = IResourcesProcessor.getClazzFQ(compilationUnit);
		 AnnotaionProcessor annotaionProcessor = new AnnotaionProcessor(clazzFQ, jdbcJarLoader);
		 if(annotaionProcessor.isremoteService()){
		 
			 pacKagename =IResourcesProcessor.getPackageName(compilationUnit);
		 
			 importsList = IResourcesProcessor.getImports(compilationUnit);
 
			 generatedInterfaceName = annotaionProcessor.getServiceInterfaceName(importsList);
		 
			 methodSignatures = annotaionProcessor.getmethodSignatures(importsList);
		 
			 TemplateProcessor templateProcessor = new TemplateProcessor(javaProject);
		 
			 if(annotaionProcessor.isAsync()){
				 templateProcessor.generateTemplate(generatedInterfaceName, importsList, pacKagename, methodSignatures);
			 }
		 
			 String ImpleName = generatedInterfaceName + "Imple";
			 String packgeName = pacKagename+".Imple";
			 importsList.add("import "+clazzFQ+";");
			 templateProcessor.generateImpleTemplate(ImpleName, packgeName, importsList, generatedInterfaceName, methodSignatures);
		 }
 		 } catch (Exception e) {
				e.printStackTrace();
			}
	}

	public void addClasspaths(IClasspathEntry[] rawClasspath,String projectClasspath) {
		
	       urls = new ArrayList<URL>();
	        if(projectClasspath!=null){
	        	 try {
						urls.add(new File(projectClasspath).toURL());
					} catch (Throwable e) {
						 /*Exception ignore*/
					}
	        }
			if(rawClasspath!=null){
				for (IClasspathEntry iClasspathEntry : rawClasspath) {
					try{
						File f = new File(iClasspathEntry.getPath().toString());
		 				urls.add(f.toURL());
				 	} catch (Throwable e) {
						 /*Exception ignore*/
					}
				}
			}
			setJdbcJarLoader(new URLClassLoader((URL[]) urls.toArray(new URL[0]), this.getClass()
					.getClassLoader()));
		}
	
	public URLClassLoader getJdbcJarLoader() {
		return jdbcJarLoader;
	}

	public void setJdbcJarLoader(URLClassLoader jdbcJarLoader) {
		this.jdbcJarLoader = jdbcJarLoader;
	}
}
