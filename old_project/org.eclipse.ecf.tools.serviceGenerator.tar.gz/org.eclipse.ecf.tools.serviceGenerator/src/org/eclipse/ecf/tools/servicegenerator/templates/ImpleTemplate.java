package org.eclipse.ecf.tools.servicegenerator.templates;

import java.util.List;

public class ImpleTemplate {

public static String getImpleTemplete(String packgeName,List<String> importsList,String className,String interfaceName,List<String[]> methods){
		
		try{
				StringBuffer buffer = new StringBuffer();
				if(!"".equals(packgeName)){
					buffer.append("package ");
					buffer.append(packgeName);
					buffer.append(";");
					}
				buffer.append("\n");
				if(!importsList.isEmpty()){
					for (String strimport : importsList) {
						buffer.append("\n"+strimport);
					}
				}
				buffer.append("\n");
				buffer.append("\npublic class " + className +" implements "+interfaceName+" { " );
				for (String[] strMethods : methods) {
					  buffer.append("\n\n\t"+strMethods[1]);
				}
				buffer.append("\n\n }");
				return buffer.toString();
            }catch (Exception e){
              return"";
            }
	}
}


/*
 	package org.jasintha.foo.imple;

	import org.jasintha.foo.Hello;

	public class HelloImple implements Hello {

		@Override
		public int add(int a, int b) {
			// TODO Auto-generated method stub
			return a +b;
		}

	}
 */