package org.eclipse.ecf.tools.serviceGenerator.processors;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IncrementalProjectBuilder;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.ecf.remoteservice.AsyncMethod;
import org.eclipse.ecf.remoteservice.AsyncService;
import org.eclipse.ecf.tools.serviceGenerator.annotaions.Async;
import org.eclipse.ecf.tools.serviceGenerator.annotaions.RemoteService;
import org.eclipse.ecf.tools.servicegenerator.templates.MethodTemplate;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;

public class AnnotaionProcessor {
	Class<?> clazz;
	private boolean isAsync;
	private int type;//0-sync 1-Async
	
  
public AnnotaionProcessor(String className,URLClassLoader jdbcJarLoader) {
	  try{
		  clazz = Class.forName(className, true, jdbcJarLoader);
	  }catch(Exception e){
		  e.printStackTrace();
	  }
   }

   public boolean isremoteService(){
	   Annotation annotation = clazz.getAnnotation(RemoteService.class);
	   if(annotation instanceof RemoteService){
	        RemoteService service = (RemoteService)annotation;
	        String type = service.type();
	        if("sync".equals(type)){ //$NON-NLS-1$
	        	isAsync =false;
	        }else if ("Async".equals(type)){ //$NON-NLS-1$
	        	isAsync =true;
	        }else{
	        	return false;
	        }
	        return true;
	   }  
	   return false;
   }
   
   public String getServiceInterfaceName(List<String> importsList){
	   String newClazz=null;
		 if(isAsync){
		    	newClazz =clazz.getSimpleName()+"Async"; //$NON-NLS-1$
		    	importsList.add("import "+clazz.getName()+"Async"+";"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
		    	importsList.add("import org.eclipse.ecf.remoteservice.IAsyncRemoteServiceProxy;");
		    }else{
		    	newClazz =clazz.getSimpleName();
		    }	
	   return newClazz;
   }
   
   public List<String[]> getmethodSignatures(List<String> importsList){
	   if(isAsync){
		   return getAsyncmethodSignatures(importsList);
	   }else{
		   return getsyncmethodSignatures();
	   }
	   
   }
   
   public List<String[]> getsyncmethodSignatures(){
	   List<String[]> strMethod = new ArrayList<String[]>();
		 Method[] methods = clazz.getMethods();
		 for (Method method : methods) {
	        		Class<?>[] parameterTypes = method.getParameterTypes();
	     			String params=null;
	     			int i=0;
	     			for (Class<?> class1 : parameterTypes) {
	     				if(params==null){
	     					params = class1.getSimpleName()+" arg"+i; //$NON-NLS-1$
	     				}else{
	     					params = params+", "+class1.getSimpleName()+" arg"+i; //$NON-NLS-1$ //$NON-NLS-2$
	     				}
	     				 i++;
	     			}
	     			strMethod.add(MethodTemplate.createMethodSignature(method.getReturnType().getSimpleName(),method.getName(), params));
		}
		 return strMethod;
   }
 
   
   public List<String[]> getAsyncmethodSignatures(List<String> importsList){
	   List<String[]> strMethod = new ArrayList<String[]>();
		 Method[] methods = clazz.getMethods();
		 for (Method method : methods) {
	         Annotation[] annotations2 = method.getAnnotations();
	         for (Annotation annotation : annotations2) {
	        	 if(annotation instanceof Async){
	        		 String finalParam=null;
	        		 
	        		 Class<?>[] parameterTypes = method.getParameterTypes();
	     			String params=null;
	     			int i=0;
	     			for (Class<?> class1 : parameterTypes) {
	     				if(params==null){
	     					params = class1.getSimpleName()+" arg"+i; //$NON-NLS-1$
	     				}else{
	     					params = params+", "+class1.getSimpleName()+" arg"+i; //$NON-NLS-1$ //$NON-NLS-2$
	     				}
	     				 i++;
	     			}
	     			 Async service = (Async)annotation;
	        		 String type = service.type();
	        		 if("future".equalsIgnoreCase(type)){ //$NON-NLS-1$
	        			 strMethod.add(MethodTemplate.createMethodSignature("IFuture",method.getName(), params)); //$NON-NLS-1$
	        			 importsList.add("import org.eclipse.equinox.concurrent.future.IFuture;");
	        		 }else if("both".equalsIgnoreCase(type)){ //$NON-NLS-1$
	        			  strMethod.add(MethodTemplate.createMethodSignature("IFuture",method.getName(), params)); //$NON-NLS-1$
	        			  importsList.add("import org.eclipse.equinox.concurrent.future.IFuture;"); //$NON-NLS-1$
	        			 if(params==null){
		 	     				params = "IAsyncCallback<String> callback"; //$NON-NLS-1$
		 	     			}else{
		 	     				params = params + ", IAsyncCallback<String> callback"; //$NON-NLS-1$
		 	     			}
	        			 strMethod.add(MethodTemplate.createMethodSignature(method.getReturnType().getSimpleName(),method.getName(), params));
	        			 importsList.add("import org.eclipse.ecf.remoteservice.IAsyncCallback;"); //$NON-NLS-1$
	        			// importsList.add("import org.eclipse.ecf.remoteservice.IAsyncRemoteServiceProxy;"); //$NON-NLS-1$
	        		 }else{
	        			 if(params==null){
	 	     				params = "IAsyncCallback<String> callback"; //$NON-NLS-1$
	 	     			}else{
	 	     				params = params + ", IAsyncCallback<String> callback"; //$NON-NLS-1$
	 	     			}
	        			 strMethod.add(MethodTemplate.createMethodSignature(method.getReturnType().getSimpleName(),method.getName(), params));
	        			 importsList.add("import org.eclipse.ecf.remoteservice.IAsyncCallback;"); //$NON-NLS-1$
	        			 //importsList.add("import org.eclipse.ecf.remoteservice.IAsyncRemoteServiceProxy;"); //$NON-NLS-1$
	        		 }
	 		    }	
			}
		}
		 return strMethod;
   }
   
   public boolean isAsync() {
		return isAsync;
	}
 
}
