package org.eclipse.ecf.tools.servicegenerator.templates;

public class RegisterTemplate {
	
	

}


/*
package org.jasintha.foo.register;

import org.eclipse.core.runtime.Platform;
import org.osgi.framework.BundleContext;
import org.osgi.util.tracker.ServiceTracker;
import org.eclipse.ecf.core.ContainerCreateException;
import org.eclipse.ecf.core.IContainer;
import org.eclipse.ecf.core.IContainerManager;
import org.eclipse.ecf.core.identity.ID;
import org.eclipse.ecf.remoteservice.IRemoteServiceContainerAdapter;
import org.eclipse.ecf.remoteservice.IRemoteServiceID;
import org.eclipse.ecf.remoteservice.IRemoteServiceRegistration;

import fooservice.Activator;

public class HelloServiceRegister {
	private ServiceTracker containerManagerServiceTracker;
	private IContainer container;
	private BundleContext context;
	private Object lock;
	private String interfaceName;
	private Object classInstance;
	private IRemoteServiceRegistration registerRemoteService;
	private String containerDescription; //ecf.r_osgi.peer

	
	
	public void Register() throws ContainerCreateException{
		
		 context = Platform.getBundle(Activator.PLUGIN_ID).getBundleContext(); 
	     IContainerManager containerManager = getContainerManagerService();
	     container= containerManager.getContainerFactory().createContainer(containerDescription);						 
		 IRemoteServiceContainerAdapter containerAdapter = (IRemoteServiceContainerAdapter) container
		.getAdapter(IRemoteServiceContainerAdapter.class);
		 setRegisterRemoteService(containerAdapter.registerRemoteService(new String[] { interfaceName }, classInstance, null));				

	}
	
	private IContainerManager getContainerManagerService() {
		if (containerManagerServiceTracker == null) {
			containerManagerServiceTracker = new ServiceTracker(context, IContainerManager.class.getName(),null);
			containerManagerServiceTracker.open();
		}
		return (IContainerManager) containerManagerServiceTracker.getService();
	}

	public IRemoteServiceRegistration getRegisterRemoteService() {
		return registerRemoteService;
	}

	public void setRegisterRemoteService(IRemoteServiceRegistration registerRemoteService) {
		this.registerRemoteService = registerRemoteService;
	}
}

 */
