package org.eclipse.ecf.tools.servicegenerator.templates;

public class ImportTemplate {
	
	//pblic static string getImport(String Fq)

}
