package org.eclipse.ecf.tools.serviceGenerator.processors;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IncrementalProjectBuilder;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IImportDeclaration;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageDeclaration;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaModelException;

public class IResourcesProcessor {
	
 public static List<String> getImports(ICompilationUnit compilationUnit) throws JavaModelException {
		List<String>  importsList = new ArrayList<String>();
		IImportDeclaration[] imports = compilationUnit.getImports();
		 for (IImportDeclaration iImportDeclaration : imports) {
			if (!"org.eclipse.ecf.tools.serviceGenerator.annotaions.Async"
					.equals(iImportDeclaration.getElementName())
					&& !"import org.eclipse.ecf.tools.serviceGenerator.annotaions.RemoteService"
							.equals(iImportDeclaration.getElementName())) {
				 importsList.add("import "+iImportDeclaration.getElementName()+";");
			}
		}
		 return importsList;
	}
 
 public static String getClazzFQ(ICompilationUnit compilationUnit)
			throws JavaModelException {
	    String className =null;
		IType[] types = compilationUnit.getTypes();
		 for ( IType iType : types) {
			 className = iType.getFullyQualifiedName();
		}
		return className;
	}

 public static String getPackageName(ICompilationUnit compilationUnit)throws JavaModelException { 
	 String pacKname ="";
	 IPackageDeclaration[] packageDeclarations = compilationUnit.getPackageDeclarations();
	 	for (IPackageDeclaration iPackageDeclaration : packageDeclarations) {
	 		pacKname =iPackageDeclaration.getElementName();
	 	}
	 	return pacKname;
	}
 
   public static IJavaProject getJavaProject(ICompilationUnit compilationUnit) throws CoreException{
	     IJavaProject javaProject = compilationUnit.getJavaProject();
		 IProject project = javaProject.getProject(); 
		 project.build(IncrementalProjectBuilder.FULL_BUILD, new NullProgressMonitor());
		 project.refreshLocal(IResource.DEPTH_INFINITE, new NullProgressMonitor());
		 return javaProject;
   }
 
}
