package org.eclipse.ecf.tools.servicegenerator.templates;

import java.util.List;

public class InterfaceTemplate {

	public static String getClassTemplete(String packgeName,List<String> importsList,String className,List<String[]> methods){
		
		try{
				StringBuffer buffer = new StringBuffer();
				if(!"".equals(packgeName)){
					buffer.append("package ");
					buffer.append(packgeName);
					buffer.append(";");
					}
				buffer.append("\n");
				if(!importsList.isEmpty()){
					for (String strimport : importsList) {
						buffer.append("\n"+strimport);
					}
				}
				buffer.append("\n");
				buffer.append("\npublic interface " + className +" extends IAsyncRemoteServiceProxy { " );
				for (String[] strMethods : methods) {
					  buffer.append("\n\n\t"+strMethods[0]);
				}
				buffer.append("\n\n }");
				return buffer.toString();
            }catch (Exception e){
              return"";
            }
	}
}
