package org.eclipse.ecf.tools.servicegenerator.templates;

import com.sun.xml.internal.ws.message.stream.StreamAttachment;

public class MethodTemplate {
	
	public static String[] createMethodSignature(String returntype,String name,String params){
		String[] methods = new String[2];
		if(params==null){
			methods[0] = "public "+returntype+" "+name+"()";
		}else{
			methods[0] = "public "+returntype+" "+name+"("+params+")";
		}
		methods[1] = createMethodBoday(methods[0], returntype);
		methods[0] = methods[0]+";";
		return  methods;
	}
	
	public static String createMethodBoday(String signature,String returnType){
		StringBuffer buffer = new StringBuffer();
		String value = findReturnValue(returnType);
		buffer.append(signature+"{ \n\t\t");
		buffer.append("// TODO Implement your logic here \n\t\t");
		if(!"1".equals(value)){
		buffer.append("return "+value+";\n\t");
		}
		buffer.append("}\n");
		return buffer.toString();
	}
	
	public static String findReturnValue(String returnType){
		
		if("int".equals(returnType)||"byte".equals(returnType)||"short".equals(returnType)||"long".equals(returnType)){
			return "0"; 
		}else if("float".equals(returnType)||"double".equals(returnType)){
			return "0.0"; 
		}else if("boolean".equals(returnType)){
			return "false"; 
		}else if("void".equals(returnType)){
			return "1";
		}else{
			return "null";
		}
	}
}
